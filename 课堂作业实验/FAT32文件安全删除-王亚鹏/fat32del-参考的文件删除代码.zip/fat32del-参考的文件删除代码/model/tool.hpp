#ifndef TOOL_HPP
#define TOOL_HPP

#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <filesystem>
#include <fstream>
#include <iostream>
#include <stdexcept>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <vector>

#include "FileEntry.hpp"

class FAT32DeleteTool {
  public:
	void listFiles(const std::string &devicePath, const std::string &directoryPath);
	void printFile(const std::string &devicePath, const std::string &directoryPath);
	void deleteFile(const std::string &devicePath, const std::string &filePath);

  private:
	std::vector<FileEntry> readSpecifiedDirectory(const std::string &devicePath, const std::string &directoryPath);
	std::vector<FileEntry> readRootDirectory(const std::string &devicePath);
	uint32_t getNextCluster(uint32_t cluster, const std::string &devicePath) {
		int fd = open(devicePath.c_str(), O_RDONLY);
		if (fd == -1) {
			throw std::runtime_error("Failed to open device");
		}

		// Calculate the FAT offset
		char bootSector[512];
		if (pread(fd, bootSector, sizeof(bootSector), 0) != sizeof(bootSector)) {
			close(fd);
			throw std::runtime_error("Failed to read boot sector");
		}

		uint16_t bytesPerSector      = *reinterpret_cast<uint16_t *>(&bootSector[11]);
		uint16_t reservedSectorCount = *reinterpret_cast<uint16_t *>(&bootSector[14]);
		uint32_t fatOffset           = reservedSectorCount * bytesPerSector + cluster * 4;

		uint32_t nextCluster;
		if (pread(fd, &nextCluster, sizeof(nextCluster), fatOffset) != sizeof(nextCluster)) {
			close(fd);
			throw std::runtime_error("Failed to read next cluster");
		}

		close(fd);
		return nextCluster;
	}

	// std::vector<uint8_t> readFileData(const FileEntry &file, const std::string &devicePath);
};

#endif