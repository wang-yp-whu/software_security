#include "tool.hpp"
#include <filesystem>

void FAT32DeleteTool::listFiles(const std::string &devicePath, const std::string &directoryPath) {
	std::vector<FileEntry> files = this->readSpecifiedDirectory(devicePath, directoryPath);

	std::cout << "Listing files in directory: " << directoryPath << "\n";
	for (const auto &file : files) {
		std::cout << file.ToString() << "\n";
	}
}

void FAT32DeleteTool::printFile(const std::string &devicePath, const std::string &filePath) {
	std::filesystem::path path(filePath);

	std::string directoryPath = path.parent_path().string();
	std::string fileName      = path.filename().string();

	// 首先在目标文件的上层中获得files entry
	std::vector<FileEntry> files = this->readSpecifiedDirectory(devicePath, directoryPath);
	FileEntry *objFileEntry      = NULL;

	for (auto &fileEntry : files) {
		if (fileEntry.EqualTo(fileName)) {
			// find it
			objFileEntry = &fileEntry;
			break;
		}
	}

	if (!objFileEntry) {
		throw std::runtime_error("can not find specified file in filePath");
		return;
	}

	// 判断是否为文件(不是文件夹)
	if (objFileEntry->IsDir()) {
		throw std::runtime_error("specifed filePath is directory, use `-l` instead");
		return;
	}

	// content output 链式读取(直接读取整个)
	auto data = objFileEntry->ReadFileData(devicePath);
	// 打印内容
	for (size_t i = 0; i < data.size(); ++i) {
		if (i > 0) {
			std::cout << " "; // 每个字节之间加一个空格
		}
		std::cout << std::uppercase << std::hex << std::setw(2) << std::setfill('0') << static_cast<int>(data[i]);
	}
	std::cout << std::endl;
	return;
}

void FAT32DeleteTool::deleteFile(const std::string &devicePath, const std::string &filePath) {
	std::filesystem::path path(filePath);

	std::string directoryPath = path.parent_path().string();
	std::string fileName      = path.filename().string();

	// 首先在目标文件的上层中获得files entry
	std::vector<FileEntry> files = this->readSpecifiedDirectory(devicePath, directoryPath);
	FileEntry *objFileEntry      = NULL;

	for (auto &fileEntry : files) {
		if (fileEntry.EqualTo(fileName)) {
			// find it
			objFileEntry = &fileEntry;
			break;
		}
	}

	if (!objFileEntry) {
		throw std::runtime_error("can not find specified file in filePath");
		return;
	}

	auto ok = objFileEntry->Remove(devicePath);
	if (!ok) {
		std::cout << "delete fail" << std::endl;
	}
}