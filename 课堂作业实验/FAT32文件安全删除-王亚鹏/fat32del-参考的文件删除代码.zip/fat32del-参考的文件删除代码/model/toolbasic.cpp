#include "tool.hpp"

std::vector<FileEntry> FAT32DeleteTool::readSpecifiedDirectory(const std::string &devicePath, const std::string &directoryPath) {
	std::vector<FileEntry> files;

	if (directoryPath == "/") { // 展示根目录
		files = this->readRootDirectory(devicePath);
	} else {
		// 遍历路径中的一个个dir
		std::filesystem::path path(directoryPath);

		// 分割路径上的各个部分
		for (const auto &part : path) {
			auto directoryName = part.string();

			if (directoryName == "/") {
				files = this->readRootDirectory(devicePath);
				// 进行判断,参考root
			} else {
				// 从上次获得的files中找到dir
				for (auto &entry : files) {
					if (entry.EqualTo(directoryName)) {
						if (!entry.IsDir()) { // not dir
							throw std::runtime_error(entry.ToString() + " is not dir");
							return files;
						} else {
							std::cout << ">>Dir " << directoryName << std::endl;
							files = entry.ParseDir(devicePath);
							break;
						}
					}
				}
			}
		}

		// throw std::runtime_error("Not implemented read directory with no root");
	}
	return files;
}

std::vector<FileEntry> FAT32DeleteTool::readRootDirectory(const std::string &devicePath) {
	std::vector<FileEntry> files;

	int fd = open(devicePath.c_str(), O_RDONLY);
	if (fd == -1) {
		throw std::runtime_error("Failed to open device");
	}

	// Read the Boot Sector to determine the root directory offset
	char bootSector[512];
	if (read(fd, bootSector, sizeof(bootSector)) != sizeof(bootSector)) {
		close(fd);
		throw std::runtime_error("Failed to read boot sector");
	}

	uint16_t bytesPerSector      = *reinterpret_cast<uint16_t *>(&bootSector[11]);
	uint8_t sectorsPerCluster    = bootSector[13];
	uint16_t reservedSectorCount = *reinterpret_cast<uint16_t *>(&bootSector[14]);
	uint8_t numFATs              = bootSector[16];
	uint32_t sectorsPerFAT       = *reinterpret_cast<uint32_t *>(&bootSector[36]);
	uint32_t rootCluster         = *reinterpret_cast<uint32_t *>(&bootSector[44]);

	// Calculate the root directory offset
	uint32_t rootDirSector   = reservedSectorCount + (numFATs * sectorsPerFAT);
	uint32_t rootRegionStart = rootDirSector * bytesPerSector;
	uint32_t clusterSize     = bytesPerSector * sectorsPerCluster;

	uint32_t currentCluster = rootCluster;

	while (currentCluster < 0x0FFFFFF8) { // FAT32 end-of-chain marker is typically >= 0x0FFFFFF8
		// Calculate the offset for the current cluster in the data region
		uint32_t clusterOffset = rootRegionStart + (currentCluster - 2) * clusterSize;

		// Seek to the root directory
		if (lseek(fd, clusterOffset, SEEK_SET) == -1) {
			close(fd);
			throw std::runtime_error("Failed to seek to specified directory");
		}
		char dirEntry[32];
		int dirEntryIndex = -1;
		while (read(fd, dirEntry, sizeof(dirEntry)) == sizeof(dirEntry)) {
			if (dirEntry[0] == 0x00) { // No more entries
				break;
			}
			if ((uint8_t)dirEntry[0] == 0xE5) { // Deleted entry
				continue;
			}
			if ((dirEntry[11] & 0x08) != 0) { // Volume label
				continue;
			}

			FileEntry file;
			file.name         = std::string(dirEntry, dirEntry + 11);
			file.firstCluster = (*reinterpret_cast<uint16_t *>(&dirEntry[26])) | ((*reinterpret_cast<uint16_t *>(&dirEntry[20])) << 16);
			file.size         = *reinterpret_cast<uint32_t *>(&dirEntry[28]);
			file.attr         = (uint8_t)dirEntry[11];
			file.entry_offset = clusterOffset + (uint32_t)dirEntryIndex * 32;
			// 晦气的.
			if (file.name[0] == '.') {
				continue;
			};
			files.push_back(file);
		}
		// Get the next cluster in the chain
		currentCluster = getNextCluster(currentCluster, devicePath);
	}

	close(fd);
	return files;
}