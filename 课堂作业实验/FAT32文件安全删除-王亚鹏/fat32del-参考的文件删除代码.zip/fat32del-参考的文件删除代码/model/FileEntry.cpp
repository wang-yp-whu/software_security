#include "FileEntry.hpp"

std::string FileEntry::ToString() const {
	std::ostringstream oss;

	// 处理文件属性
	oss << ((attr & 0x10) ? 'd' : '-'); // 目录(d)或文件(-)
	oss << ((attr & 0x01) ? 'r' : '-'); // 只读文件(r)或普通(-)
	oss << ((attr & 0x02) ? 'h' : '-'); // 隐藏文件(h)或普通(-)
	oss << ((attr & 0x04) ? 's' : '-'); // 系统文件(s)或普通(-)
	oss << ((attr & 0x20) ? 'a' : '-'); // 归档文件(a)或普通(-)

	// 添加文件信息
	oss << " ";
	oss << std::setw(8) << std::right << size; // 文件大小，右对齐，宽度8

	// 文件名
	oss << " " << name;

	// // 显示起始簇号（可选）
	// oss << " [Cluster: " << firstCluster << "]";

	return oss.str();
}

bool FileEntry::IsDir() {
	return (attr & 0x10) ? true : false;
}

std::string convertToFat32Format(const std::string &filePath);
bool FileEntry::EqualTo(std::string fileName) {
	return this->name == convertToFat32Format(fileName);
}
// 将文件路径转换为FAT32的8.3格式
std::string convertToFat32Format(const std::string &filePath) {
	std::string fileName, extension;
	size_t dotPos = filePath.find_last_of('.');

	// 获取文件名和扩展名部分
	if (dotPos != std::string::npos) {
		fileName  = filePath.substr(0, dotPos);
		extension = filePath.substr(dotPos + 1);
	} else {
		fileName = filePath;
	}

	// 转换为大写
	std::transform(fileName.begin(), fileName.end(), fileName.begin(), ::toupper);
	std::transform(extension.begin(), extension.end(), extension.begin(), ::toupper);

	// 截断或填充文件名至8字符
	if (fileName.length() > 8) {
		fileName = fileName.substr(0, 8);
	} else {
		fileName.append(8 - fileName.length(), ' ');
	}

	// 截断或填充扩展名至3字符
	if (extension.length() > 3) {
		extension = extension.substr(0, 3);
	} else {
		extension.append(3 - extension.length(), ' ');
	}

	// 合并文件名和扩展名
	return fileName + extension;
}

std::vector<FileEntry> FileEntry::ParseDir(const std::string &devicePath) {
	auto ret = std::vector<FileEntry>();

	int fd = open(devicePath.c_str(), O_RDONLY);
	if (fd == -1) {
		throw std::runtime_error("Failed to open device");
	}

	// Read the Boot Sector to get file system parameters
	char bootSector[512];
	if (pread(fd, bootSector, sizeof(bootSector), 0) != sizeof(bootSector)) {
		close(fd);
		throw std::runtime_error("Failed to read boot sector");
	}

	uint16_t bytesPerSector      = *reinterpret_cast<uint16_t *>(&bootSector[11]);
	uint8_t sectorsPerCluster    = bootSector[13];
	uint16_t reservedSectorCount = *reinterpret_cast<uint16_t *>(&bootSector[14]);
	uint8_t numFATs              = bootSector[16];
	uint32_t sectorsPerFAT       = *reinterpret_cast<uint32_t *>(&bootSector[36]);

	// Calculate the data region start
	uint32_t dataRegionStart = (reservedSectorCount + numFATs * sectorsPerFAT) * bytesPerSector;
	uint32_t clusterSize     = bytesPerSector * sectorsPerCluster;

	// Prepare to read file data
	uint32_t currentCluster = this->firstCluster;

	while (currentCluster < 0x0FFFFFF8) { // FAT32 end-of-chain marker is typically >= 0x0FFFFFF8
		// Calculate the offset for the current cluster in the data region
		uint32_t clusterOffset = dataRegionStart + (currentCluster - 2) * clusterSize;

		// Seek to the root directory
		if (lseek(fd, clusterOffset, SEEK_SET) == -1) {
			close(fd);
			throw std::runtime_error("Failed to seek to specified directory");
		}
		char dirEntry[32];
		int dirEntryIndex = -1;
		while (read(fd, dirEntry, sizeof(dirEntry)) == sizeof(dirEntry)) {
			dirEntryIndex += 1;
			if (dirEntry[0] == 0x00) { // No more entries
				break;
			}
			if ((uint8_t)dirEntry[0] == 0xE5) { // Deleted entry
				continue;
			}
			if ((dirEntry[11] & 0x08) != 0) { // Volume label
				continue;
			}

			FileEntry file;
			file.name         = std::string(dirEntry, dirEntry + 11);
			file.firstCluster = (*reinterpret_cast<uint16_t *>(&dirEntry[26])) | ((*reinterpret_cast<uint16_t *>(&dirEntry[20])) << 16);
			file.size         = *reinterpret_cast<uint32_t *>(&dirEntry[28]);
			file.attr         = (uint8_t)dirEntry[11];
			file.entry_offset = clusterOffset + (uint32_t)dirEntryIndex * 32;

			// 晦气的.
			if (file.name[0] == '.') {
				continue;
			}
			ret.push_back(file);
		}
		// Get the next cluster in the chain
		currentCluster = getNextCluster(currentCluster, devicePath);
	}

	close(fd);
	return ret;
}

std::vector<uint8_t> FileEntry::ReadFileData(const std::string &devicePath) {
	int fd = open(devicePath.c_str(), O_RDONLY);
	if (fd == -1) {
		throw std::runtime_error("Failed to open device");
	}

	// Read the Boot Sector to get file system parameters
	char bootSector[512];
	if (pread(fd, bootSector, sizeof(bootSector), 0) != sizeof(bootSector)) {
		close(fd);
		throw std::runtime_error("Failed to read boot sector");
	}

	uint16_t bytesPerSector      = *reinterpret_cast<uint16_t *>(&bootSector[11]);
	uint8_t sectorsPerCluster    = bootSector[13];
	uint16_t reservedSectorCount = *reinterpret_cast<uint16_t *>(&bootSector[14]);
	uint8_t numFATs              = bootSector[16];
	uint32_t sectorsPerFAT       = *reinterpret_cast<uint32_t *>(&bootSector[36]);

	// Calculate the data region start
	uint32_t dataRegionStart = (reservedSectorCount + numFATs * sectorsPerFAT) * bytesPerSector;
	uint32_t clusterSize     = bytesPerSector * sectorsPerCluster;

	// Prepare to read file data
	std::vector<uint8_t> fileData;
	uint32_t currentCluster = this->firstCluster;
	uint32_t bytesRead      = 0;

	while (currentCluster < 0x0FFFFFF8 && bytesRead < this->size) { // FAT32 end-of-chain marker is typically >= 0x0FFFFFF8
		// Calculate the offset for the current cluster in the data region
		uint32_t clusterOffset = dataRegionStart + (currentCluster - 2) * clusterSize;

		// Read the cluster data
		std::vector<uint8_t> clusterData(clusterSize);
		if (pread(fd, clusterData.data(), clusterSize, clusterOffset) != clusterSize) {
			close(fd);
			throw std::runtime_error("Failed to read cluster data");
		}

		// Append the data from this cluster to the file data buffer
		uint32_t toRead = std::min(clusterSize, this->size - bytesRead); // Ensure we don’t read past the file size
		fileData.insert(fileData.end(), clusterData.begin(), clusterData.begin() + toRead);
		bytesRead += toRead;

		// Get the next cluster in the chain
		currentCluster = getNextCluster(currentCluster, devicePath);
	}

	close(fd);
	return fileData;
}

uint32_t FileEntry::getNextCluster(uint32_t cluster, const std::string &devicePath) {
	int fd = open(devicePath.c_str(), O_RDONLY);
	if (fd == -1) {
		throw std::runtime_error("Failed to open device");
	}

	// Calculate the FAT offset
	char bootSector[512];
	if (pread(fd, bootSector, sizeof(bootSector), 0) != sizeof(bootSector)) {
		close(fd);
		throw std::runtime_error("Failed to read boot sector");
	}

	uint16_t bytesPerSector      = *reinterpret_cast<uint16_t *>(&bootSector[11]);
	uint16_t reservedSectorCount = *reinterpret_cast<uint16_t *>(&bootSector[14]);
	uint32_t fatOffset           = reservedSectorCount * bytesPerSector + cluster * 4;

	uint32_t nextCluster;
	if (pread(fd, &nextCluster, sizeof(nextCluster), fatOffset) != sizeof(nextCluster)) {
		close(fd);
		throw std::runtime_error("Failed to read next cluster");
	}

	close(fd);
	return nextCluster;
}

bool FileEntry::Remove(const std::string &devicePath) {
	if (this->IsDir()) {
		return this->RemoveDir(devicePath);
	}
	std::cout << "Now deleting " << this->ToString() << std::endl;

	int fd = open(devicePath.c_str(), O_RDWR); // 开启设备文件的读写模式
	if (fd == -1) {
		throw std::runtime_error("Failed to open device");
	}

	// 读取Boot Sector以获取文件系统参数
	char bootSector[512];
	if (pread(fd, bootSector, sizeof(bootSector), 0) != sizeof(bootSector)) {
		close(fd);
		throw std::runtime_error("Failed to read boot sector");
	}

	uint16_t bytesPerSector      = *reinterpret_cast<uint16_t *>(&bootSector[11]);
	uint8_t sectorsPerCluster    = bootSector[13];
	uint16_t reservedSectorCount = *reinterpret_cast<uint16_t *>(&bootSector[14]);
	uint8_t numFATs              = bootSector[16];
	uint32_t sectorsPerFAT       = *reinterpret_cast<uint32_t *>(&bootSector[36]);

	// 计算数据区域的起始位置
	uint32_t dataRegionStart = (reservedSectorCount + numFATs * sectorsPerFAT) * bytesPerSector;
	uint32_t clusterSize     = bytesPerSector * sectorsPerCluster;

	uint32_t currentCluster = this->firstCluster;

	// 覆盖文件数据
	while (currentCluster < 0x0FFFFFF8) { // FAT32的结束标记通常大于等于0x0FFFFFF8
		// 计算当前簇的偏移位置
		uint32_t clusterOffset = dataRegionStart + (currentCluster - 2) * clusterSize;

		// 获取下一个簇并将当前簇标记为空闲
		uint32_t nextCluster = getNextCluster(currentCluster, devicePath);

		// 用0覆盖当前簇的数据
		std::vector<uint8_t> zeroData(clusterSize, 0);
		if (pwrite(fd, zeroData.data(), clusterSize, clusterOffset) != clusterSize) {
			close(fd);
			throw std::runtime_error("Failed to overwrite cluster data");
		}

		// 计算FAT表的偏移并标记为0
		uint32_t fatOffset = reservedSectorCount * bytesPerSector + currentCluster * 4; // 每项4字节
		uint32_t zeroValue = 0;
		if (pwrite(fd, &zeroValue, 4, fatOffset) != 4) {
			close(fd);
			throw std::runtime_error("Failed to update FAT table");
		}

		currentCluster = nextCluster;
	}

	uint8_t deleteFlag = 0xE5; // FAT32删除标记
	if (pwrite(fd, &deleteFlag, 1, this->entry_offset) != 1) {
		close(fd);
		throw std::runtime_error("Failed to update directory entry");
	}

	if (fsync(fd) == -1) {
		throw std::runtime_error("Failed to sync file system changes");
	}
	close(fd);
	return true;
}

bool FileEntry::RemoveDir(const std::string &devicePath) {
	if (!this->IsDir()) {
		throw std::runtime_error("this is a file");
		return false;
	}
	auto files = this->ParseDir(devicePath);
	for (auto &entry : files) {
		entry.Remove(devicePath);
	}
	// 最后删除自己

	int fd = open(devicePath.c_str(), O_RDWR); // 开启设备文件的读写模式
	if (fd == -1) {
		throw std::runtime_error("Failed to open device");
	}

	// 读取Boot Sector以获取文件系统参数
	char bootSector[512];
	if (pread(fd, bootSector, sizeof(bootSector), 0) != sizeof(bootSector)) {
		close(fd);
		throw std::runtime_error("Failed to read boot sector");
	}

	uint16_t bytesPerSector      = *reinterpret_cast<uint16_t *>(&bootSector[11]);
	uint8_t sectorsPerCluster    = bootSector[13];
	uint16_t reservedSectorCount = *reinterpret_cast<uint16_t *>(&bootSector[14]);
	uint8_t numFATs              = bootSector[16];
	uint32_t sectorsPerFAT       = *reinterpret_cast<uint32_t *>(&bootSector[36]);

	// 计算数据区域的起始位置
	uint32_t dataRegionStart = (reservedSectorCount + numFATs * sectorsPerFAT) * bytesPerSector;
	uint32_t clusterSize     = bytesPerSector * sectorsPerCluster;

	uint32_t currentCluster = this->firstCluster;

	// 覆盖文件数据
	while (currentCluster < 0x0FFFFFF8) { // FAT32的结束标记通常大于等于0x0FFFFFF8
		// 计算当前簇的偏移位置
		uint32_t clusterOffset = dataRegionStart + (currentCluster - 2) * clusterSize;

		// 用0覆盖当前簇的数据
		std::vector<uint8_t> zeroData(clusterSize, 0);
		if (pwrite(fd, zeroData.data(), clusterSize, clusterOffset) != clusterSize) {
			close(fd);
			throw std::runtime_error("Failed to overwrite cluster data");
		}

		// 获取下一个簇并将当前簇标记为空闲
		uint32_t nextCluster = getNextCluster(currentCluster, devicePath);

		// 计算FAT表的偏移并标记为0
		uint32_t fatOffset = reservedSectorCount * bytesPerSector + currentCluster * 4; // 每项4字节
		uint32_t zeroValue = 0;
		if (pwrite(fd, &zeroValue, 4, fatOffset) != 4) {
			close(fd);
			throw std::runtime_error("Failed to update FAT table");
		}

		currentCluster = nextCluster;
	}

	uint8_t deleteFlag = 0xE5; // FAT32删除标记
	if (pwrite(fd, &deleteFlag, 1, this->entry_offset) != 1) {
		close(fd);
		throw std::runtime_error("Failed to update directory entry");
	}

	if (fsync(fd) == -1) {
		throw std::runtime_error("Failed to sync file system changes");
	}

	close(fd);
	return true;
}