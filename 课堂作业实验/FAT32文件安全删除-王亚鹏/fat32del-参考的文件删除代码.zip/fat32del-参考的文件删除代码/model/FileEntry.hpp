#ifndef FILE_ENTRY_HPP
#define FILE_ENTRY_HPP

#include <algorithm>
#include <cctype>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <fcntl.h>
#include <filesystem>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <sstream>
#include <stdexcept>
#include <string>
#include <sys/stat.h>
#include <sys/types.h>
#include <unistd.h>
#include <vector>

class FileEntry {
  public:
	std::string name;
	uint32_t firstCluster;
	uint32_t size;
	uint8_t attr;
	uint32_t entry_offset;

	std::string ToString() const; // 打印调试用字符串
	bool IsDir();
	bool EqualTo(std::string fileName); // fat32风格的name是否与unicode的名称相同

	// 说实话这里应该实现IEntry接口并让FileEntry和DirEntry实现,但是已经先到这里还是算了
	std::vector<uint8_t> ReadFileData(const std::string &devicePath);
	std::vector<FileEntry> ParseDir(const std::string &devicePath); // 像dir一样解析

	// modify
	bool Remove(const std::string &devicePath);
	bool RemoveDir(const std::string &devicePath);

  private:
	uint32_t getNextCluster(uint32_t cluster, const std::string &devicePath);
};

#endif