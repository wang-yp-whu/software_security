#include <iostream>

#include "model/tool.hpp"

int main(int argc, char *argv[]) {
	if (argc < 4) {
		std::cerr << "Usage: tool.out -l <devicePath> <directoryPath> or tool.out -d <devicePath> <filePath>\n";
		return 1;
	}

	FAT32DeleteTool tool;
	try {
		std::string command    = argv[1];
		std::string devicePath = argv[2];
		std::string path       = argv[3];

		if (command == "-l") {
			tool.listFiles(devicePath, path);
		} else if (command == "-d") {
			tool.deleteFile(devicePath, path);
		} else if (command == "-f") {
			tool.printFile(devicePath, path);
		} else {
			throw std::invalid_argument("Unknown command");
		}
	} catch (const std::exception &ex) {
		std::cerr << "Error: " << ex.what() << "\n";
		return 1;
	}

	return 0;
}
